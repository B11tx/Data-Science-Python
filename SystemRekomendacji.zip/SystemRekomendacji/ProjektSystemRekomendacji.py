import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


movies  = pd.read_csv("movies.csv")
ratings = pd.read_csv("ratings.csv")

print("Dane Załadowane")

ratings_count = ratings.groupby('movieId')['rating'].count().reset_index()

ratings_count.columns = ['movieId', 'liczba_ocen']

final_df = pd.merge(movies, ratings_count, on='movieId')

top_movies = final_df.sort_values(by='liczba_ocen', ascending=False)


print("\nTOP 10 NAJCZĘŚCIEJ OCENIANYCH FILMÓW:")
print(top_movies[['title', 'liczba_ocen']].head(10).to_string(index=False))


#Macierz
full_data = pd.merge(ratings, movies, on='movieId')

matrix = full_data.pivot_table(index='userId', columns='title', values='rating')

matrix = matrix.fillna(0)

print("\nMacierz utworzona")
print(matrix.iloc[:5, :5].to_string())

print(f"\nRozmiar macierzy: {matrix.shape}")


#Wykres
plt.figure(figsize=(10,4))

final_df['liczba_ocen'].hist(bins=70, edgecolor='black')

plt.title('Rozkład liczby ocen (Większość filmów ma mało ocen)')
plt.xlabel('Liczba ocen')
plt.ylabel('Liczba filmów')

plt.show()

#System Rekomendacji

stats = final_df.set_index('title')['liczba_ocen']


def get_recommendations(movie_title, min_ratings=50):


    try:

        user_ratings = matrix[movie_title]
    except KeyError:
        return "Błąd: Film nie znaleziony w bazie ."


    similar_movies = matrix.corrwith(user_ratings)

    corr_df = pd.DataFrame(similar_movies, columns=['Correlation'])
    corr_df.dropna(inplace=True)
    corr_df = corr_df.join(stats)

    recommendations = corr_df[corr_df['liczba_ocen'] > min_ratings].sort_values('Correlation', ascending=False)

    return recommendations.head(10)


# Test 1
film1 = 'Star Wars: Episode IV - A New Hope (1977)'
print(f"\nFilmy podobne do: {film1}")
print(get_recommendations(film1))

# Test 2
film2 = 'Forrest Gump (1994)'
print(f"\nFilmy podobne do: {film2}")
print(get_recommendations(film2))



